public class COAC {

    AgrupacionOficial [] agrupaciones;
    AgrupacionOficial agrupacion;
    Agrupacion agrup;

    public COAC(AgrupacionOficial[] agrupaciones) {
        this.agrupaciones = agrupaciones;
    }

    public void inscribir_agrupacion(AgrupacionOficial agrupacion) {

    }

    public boolean eliminar_agrupacion(AgrupacionOficial agrupacion){
        return false;
    }

    public void ordenar_por_puntos(){

    }

    public void ordenar_por_nombre(){

    }

    public void ordenar_por_autor(){

    }

    public Agrupacion[] getAgrupaciones() {
        return agrupaciones;
    }

    public void setAgrupaciones(AgrupacionOficial[] agrupaciones) {
        this.agrupaciones = agrupaciones;
    }
}

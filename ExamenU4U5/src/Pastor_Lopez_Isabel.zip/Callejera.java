public interface Callejera {
    void amo_a_escucha();
}
